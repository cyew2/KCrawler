<?php
	$apiBank = array(
"AIzaSyAg5R3t-MeiGh5WcMsR5x2UjnwOp_DlSnM",
"AIzaSyCBpaW6mP93eUiUWAcBTlxCVxWnr6X9FvQ",
"AIzaSyBRh16uLSlXCwBwoHtasDYgV6cgZAnimOI",
"AIzaSyCCrQjkVb2hSpLSeexyNWFjja28LEmvgX8",
"AIzaSyDNTEJ4tcfxzABOrk7ah1GCU3nBZlXadvI",
"AIzaSyBbPInX_c6x2x77jIPpkcpOKuohIpswQU4");
?>