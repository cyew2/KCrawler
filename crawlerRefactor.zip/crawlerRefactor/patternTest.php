 <?php
include('simple_html_dom.php');
$html = file_get_html("http://www.parolesmania.com/paroles_ed_sheeran_66964/paroles_perfect_2015032.html");
		$lData=$html->find('.lyrics-body',0);
		var_dump($html);
		$lData=$lData->innertext;
         
        echo $lData;

?>
