<?php 
function converter($t){
	$removePattern = array('/♪/u','/♬/u','/≈/u','/🎸/u','/💋/u','/📣/u',
							'/💖/u','/🎹/u','/❤/u','/☆/u','/🎶/u','/🔊/u','/🕪/u',
							'/⬇/u','/✴/u','/■/u','/□/u','/♠/u','/◆/u',
							'/◇/u','/♣/u','/█/u','/≡/u','/🌹/u','/✔/u','/①/u','/②/u','/③/u',
							'/♫/u','/♥/u','/&#xD;/u','/□/u');
	
	$t= preg_replace($removePattern,"\n",$t);
	$t= preg_replace("/&gt;/u","\n",$t);
	$t= preg_replace("/&lt;/u","\n",$t);
	$t= preg_replace("/<br>/u","\n",$t);
	$t= preg_replace("/<\\\\\/br>+/u","\n",$t);
	$t= preg_replace("/<\/br>+/u","\n",$t);
	$t= preg_replace("/<br \\\\\/>+/u","\n",$t);
	$t= preg_replace("/<br \/>+/u","\n",$t);
	$t= preg_replace("/<p>/u","\n",$t);
	$t= preg_replace("/<\\\\\/p>/u","\n",$t);
	$t= preg_replace("/<\/p>/u","\n",$t);
	$t= strtolower($t);
	//$t= preg_replace("/\/","",$t);
	$t= preg_replace("/<[\\\\!a-zA-Z0-9#;:.&%?=()+,\/' \"_\-]*>/u","",$t);
	//echo $t;
	$t= preg_replace("/ i /u"," I ",$t);
	$t= preg_replace("/ i+[\r\n]/u"," I\n",$t);
	$t= preg_replace("/ i'/u"," I'",$t);

	$t= preg_replace("/[,.;?!(){}–\[\]\/\-]/u"," ",$t);
	$t= preg_replace("/…/u"," ",$t);
	$t= preg_replace("/[|“”：\"*><\^=:_@#$%~\+\t]/u","",$t);
	$t= preg_replace("/ +/u"," ",$t);

	$t= preg_replace("/\n\t+/u","\n",$t);
	$t= preg_replace("/[\r\n]+/u","\n",$t);
	$t= preg_replace("/\n /u","\n",$t);
	$t= preg_replace("/\t+/u","\n",$t);
	$t= preg_replace("/ +\n+/u","\n",$t);
	$t= preg_replace("/ +/u"," ",$t);
	$t= preg_replace("/[\r\n]+/u","\n",$t);
	$t = shortiFy($t);
	
	/////////....need some conversion....////

	/*while($t[0]=="\n"||$t[0]==" ")
	{
	$t = substr($t,1);
	}
	while($t[strlen($t)-1]=="\n"||$t[strlen($t)-1]==" ")
	{
	$t = substr($t,0,strlen($t)-1);
	}*/
	$t= ucfirst($t);
	$t = toCapitalCase($t);
	$t = badWords($t);
	$t = punc($t);
	$t= preg_replace("/ i /u"," I ",$t);
	$t= preg_replace("/ i+[\r\n]/u"," I\n",$t);
	$t= preg_replace("/ i'/u"," I'",$t);
	
	$t= preg_replace("/\n/u","\r\n",$t);
	return $t;
}

function saveTxtfile($filename,$fline,$tobeSaved,$dirName){
	
	/*$formatedData = utf8_decode($tobeSaved['lyrics']);
	$formatedData=str_replace("&#xD;", "", $formatedData);*/
	 $formatedData = mb_convert_encoding($tobeSaved['lyrics'], 'UTF-8', mb_detect_encoding($tobeSaved['lyrics'])); 
	 $formatedData=str_replace("&#xD;", "", $formatedData);
	$fline=str_replace("?", "-", utf8_decode($fline));
	$written=str_replace("?", ":", utf8_decode("Written by："));
	$fileName = $filename.".txt";
	$filee = $fileName;
	$myfile = fopen($filee, "w+") or die("Unable to open file!");
	
	fwrite($myfile, $tobeSaved['link']);
	fwrite($myfile, "\r\n");
	fwrite($myfile, "\r\n");
	fwrite($myfile, $fline);
	fwrite($myfile, "\r\n");
	fwrite($myfile, $written);
	fwrite($myfile, "\r\n");
	
	if($formatedData!='')
		fwrite($myfile, $formatedData);
	else
		fwrite($myfile, "No lyrics found");
	fclose($myfile);
}

function saveTxtfile2($lyrics){
	
	$formatedData = utf8_decode($lyrics);
	$formatedData=str_replace("&#xD;", "", $formatedData);
	$fileName = "C:\Users\Company Laptop2\Desktop\mp3\hrror\sest2.txt";
	$filee = $fileName;
	$myfile = fopen($filee, "w+") or die("Unable to open file!");
	
	fwrite($myfile, "\r\n");
	
	if($formatedData!='')
		fwrite($myfile, $formatedData);
	else
		fwrite($myfile, "No lyrics found");
	fclose($myfile);
}

function saveToJson($filename,$tobesaved){
   $arr_data = array(); // create empty array
   $jsondata=null;
  try
  {
    if (file_exists($filename.'.json')) {
        $jsondata = file_get_contents($filename.'.json');
    } else {
        file_put_contents($filename.'.json', '');
    }
     // converts json data into array
     
     if(!is_null($jsondata))
        $arr_data = json_decode($jsondata, true);

     // Push user data to array
      if(isset($arr_data[$tobesaved['songid']])){
      	for ($i=0; $i < sizeof($arr_data[$tobesaved['songid']]); $i++) { 
      		if($arr_data[$tobesaved['songid']][$i]['link'] == $tobesaved['link']){
      			$tobesaved['lyrics'] = utf8_decode($tobesaved['lyrics']);
				$tobesaved['lyrics']=str_replace("&#xD;", "", $tobesaved['lyrics']);
      			 $arr_data[$tobesaved['songid']][$i]['lyrics']=$tobesaved['lyrics'];
      		}
      	}
       
      }
        

       //Convert updated array to JSON
     $jsondata = json_encode($arr_data, JSON_PRETTY_PRINT);
     //write json data into data.json file
     file_put_contents($filename.".json", $jsondata);

  }
  catch (Exception $e) {
    echo 'Caught exception: ',  $e->getMessage(), "\n";
  }
 }

function toCapitalCase($t)
{
	$sku = explode(PHP_EOL, $t);
	$new="";
	foreach ($sku as $key => $value) {
		$new.=ucfirst($value).''.PHP_EOL;
	}
	return $new;
/*	$i = 0;
	while($pos = strpos($t,"\n",$i))
	{
	$t = substr($t,0,$pos+1).strtoupper($t[$pos+1]).substr($t,$pos+2);
	$i = $pos+1;
	}	
	return $t;*/
}
function badWords($t){
	$bad=array('bitch','bitches','bullshit','damn','fucking','penis','shit','cock','cum','hoes','nigga','ass');
	$badreplace=array('b*tch','b*tches','bullsh*t','d*mn',"f**kin'",'p*nis','sh*t','cock','cum','hoes','nigga','ass');

	foreach ($bad as $key => $value) {
		$t=str_replace(" ".$value." "," ".$badreplace[$key]." ",$t);
	}

	return $t;
}

function punc($t){
	$punc=array("coz","cause","cuz","em","til","ive");
	$puncreplace=array("'coz","'Cause","'cuz","'em","'til","I've");

	foreach ($punc as $key => $value) {
		$t=str_replace(" ".$value." "," ".$puncreplace[$key]." ",$t);
	}

	return $t;
}

function shortiFy($t)
{
	$len= strlen($t);
	$count = 0;
	for ($i=0; $i<$len; $i++)
	{
		if ($t[$i] == "\n")
			$count=0;
		else if ($t[$i]== " ")
			$count++;
		else{
		}

		if ($count == 10)
		{
			$t = substr($t,0,$i)."\n".substr($t,$i+1);
			$count=0;
			$i++;
		}
	}
	return $t;
}
?>