<?php
include 'clean.php';
$lyrics='';
if(isset($_POST['data']['lyrics']) && $_POST['data']['lyrics'] != "no lyrics"){
	$lyrics=nl2br($_POST['data']['lyrics']);
	$lyrics=str_replace("<br />", "", $lyrics);
	$lyrics=strip_tags($lyrics,"<br>");
	
	$lyrics=str_replace("<br>", PHP_EOL,$lyrics);
	//$lyrics = converter($lyrics);
}else{
	$lyrics='';
}
$_POST['filename']=str_replace(".txt", "", $_POST['filename']);

saveTxtfile($_POST['filename'],$_POST['firstline'],array('id'=>$_POST['data']['id'],'songid'=>$_POST['data']['songid'],'lyrics'=>$lyrics,'link'=>$_POST['data']['link']),$_POST['dirname']);

	echo json_encode(array('success'=>true,'lyrics'=>$lyrics));

?>