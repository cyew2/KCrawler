<?php
include 'clean.php';

$test='Aéro dynamik
perfection mékanik
aéro dynamik
Materiel et technik
Aéro dynamik
Aéro dynamik
Condition et physik
Aéro dynamik
Position et taktik
Aéro dynamik
Aéro dynamik
Perfection mékanik
Aéro dynamik
Materiel et technik
Aéro dynamik
Condition et physik
Aéro dynamik
Position et taktik';

var_dump(toCapitalCase($test));
?>