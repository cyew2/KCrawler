<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<style type="text/css">
	/* The Modal (background) */
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content/Box */
.modal-content {
    background-color: #fefefe;
    margin: 15% auto; /* 15% from the top and centered */
    padding: 20px;
    border: 1px solid #888;
    width: 80%; /* Could be more or less, depending on screen size */
}

/* The Close Button */
.close {
    color: #aaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
}

.close:hover,
.close:focus {
    color: black;
    text-decoration: none;
    cursor: pointer;
}
</style>
<body>
<form method="GET" >
	PATH: <input type="text" name="path"> <input type="submit" name="submit" value="Check">
</form> 
<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content" style="width: 400px;">
    <span class="close">&times;</span>
    <div id="lyricCOntent" style="text-align: center;">Some text in the Modal..</div>
  </div>

</div>
<div id="myModal2" class="modal">

  <!-- Modal content -->
  <div class="modal-content" style="    width: 450px;">
    <span class="close close2">&times;</span>
    <input type="hidden" name="xpath" class="xpath" />
    <textarea cols="60" rows="30" class="lyrictextarea"></textarea>
    <center style="display:block"><button onclick="saveLyrics()">Save Lyrics</button></center>
  </div>

</div>
</body>
<script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>
<script type="text/javascript">
	// Get the modal
var modal = document.getElementById('myModal');

// Get the button that opens the modal
var btn = document.getElementsByClassName("viewLyrics");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on the button, open the modal 
btn.onclick = function() {
	console.log('sdfdsfds');
    modal.style.display = "block";
}

function saveLyrics(){
		var path=$('#myModal2').find('.xpath').val();
		var lyric=$('.lyrictextarea').val();

		$.ajax({
		  url: '/cleansing/clean.php',
		  data: {'path':path,'lyrics':lyric,'type':'addlyrics'},
		  success: function(){
		  	document.getElementById('myModal2').style.display = "none";
		  	alert('Lyrics Added!');
		  	location.reload();
		  },
		  datatype:'application/json'
		});

}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}


$(function() {
	$('.close2').on('click',function(){
	    document.getElementById('myModal2').style.display = "none";
	});
	$('.viewLyrics').on('click',function(){
		var lyrics=$(this).parent().parent().find('.hiddenlyrics').html();
		$('#lyricCOntent').html(lyrics);
    	modal.style.display = "block";
	});

	$('.addlyric').on('click',function(){
		var path=$(this).parent().find('.path').val();
		$('#myModal2').find('.xpath').val(path);
		document.getElementById('myModal2').style.display = "block";
	})

	$('.markCorrect').on('click',function(){
		var path=$(this).parent().find('.path').val();
		var basepath=path.split("/unsurelyrics")[0];
		var filename=path.split("/unsurelyrics")[1];
		$.ajax({
		  url: '/cleansing/clean.php',
		  data: {'path':path,'basepath':basepath,'filename':filename,'type':'unsure'},
		  success: function(){
		  	alert('Saved!');
		  	location.reload();
		  },
		  datatype:'application/json'
		});

	});

	$('.markCorrect2').on('click',function(){
		var path=$(this).parent().find('.path').val();
		var basepath=path.split("/nolyrics")[0];
		var filename=path.split("/nolyrics")[1];
		$.ajax({
		  url: '/cleansing/clean.php',
		  data: {'path':path,'basepath':basepath,'filename':filename,'type':'unsure'},
		  success: function(){
		  	alert('Saved!');
		  	location.reload();
		  },
		  datatype:'application/json'
		});

	});
	
});


</script>
</html>
<?php

if(isset($_GET['path'])){
	$path=$_GET['path'];

   $files = glob($path."\*.txt");
   if (!file_exists($path."\/nolyrics"))
   	mkdir($path."\/nolyrics");
   if (!file_exists($path."\/unsurelyrics"))
   	mkdir($path."\/unsurelyrics");



   $nolyricsdir=$path."\/nolyrics\/";
   $unsurelyricsdir=$path."\/unsurelyrics\/";
   $withlyricsdir=$path."\/withlyricsdir\/";

   chmod($nolyricsdir,0777);
   chmod($unsurelyricsdir,0777);
   chmod($withlyricsdir,0777);

   $delete=array();
   echo '<table class="table"><thead><th>Song ID</th>
			<th style="width: 20%;">Song</th>
			<th style="width: 20%;">Link</th>
			<th style="width: 50%;">Lyrics Overview</th>
			<th>Action</th>
		</thead>
		<tbody>';
    $nolyrics=array();
    $unsure=array();
    foreach($files as $file) {
    	chmod($file,0777);
    	$filename=basename($file);
    	
    	$songid=explode("_", $filename)[0];
    	$lyricscontent=false;
    	$titlepart=-1;
    	$titlecount=0;
    	$song="";
		$data = file($file);
		$nolyric=false;
		$link="";

		$d=new SplFileObject($file);
		foreach ($d as $lineNumber => $lineContent) {
		    if($lyricscontent==false) {
		    	if(stripos($lineContent,"http://")!==false || stripos($lineContent,"https://")!==false){
		    		$link=$lineContent;
		    	}
		    	if(stripos($lineContent,"Written by")!==false){
		        	$lyricscontent=true;
		       		$titlepart= $lineNumber-1;
		       	}
		    }
		    if(stripos($lineContent,"Written by")==false && $lyricscontent==true){
		    	if(stripos($lineContent, "No lyrics available") > -1){
		    		$nolyric=true;
		    		break;
		    	}
		    	$song=$data[count($titlepart)+1];
		    	$title=explode("–", $song)[0];
		    	
		    	if(stripos($lineContent,trim($title))!=false)
		    		$titlecount++;
		    }
		   // $wholelines=$wholelines.''.preg_replace("/[^a-z']+/i", '', $lineContent);
		}
		
		$line = $data[count($data)-1];
		if(stripos($line,"Written by")!==false){
			
			 if (copy($file, $nolyricsdir.'\/'.$filename)) {
			 	if (file_exists($file)){
			  		unlink($file);
			 	}
	         }
		}else{
			
			$lines="";
			$fileIterator = new LimitIterator($d, 4, 5);

			foreach($fileIterator as $line) {
			    $lines= $lines.''.$line.'<br/>';
			}
			if(iterator_count($fileIterator) > 0){
			  	if($titlecount==0){
			  		if($nolyric==false){
			  			if (copy($file, $unsurelyricsdir.'\/'.$filename)) {
			  				array_push($unsure, $file);
				        }
					}else{
						if (copy($file, $nolyricsdir.'\/'.$filename)) {
			  				  unlink($file);
				        }
					}
	  			}else{
	  				if (copy($file, $withlyricsdir.'\/'.$filename)) {
			  				 array_push($unsure, $file);
				        }
	  				
	  			}
			}else{
				if (copy($file, $nolyricsdir.'\/'.$filename)) {
					if (file_exists($file)){
						unlink($file);
					}
		            
		         }

			}

    	}
    	$d=null;
    	
    }
    if(count($unsure) > 0){
    	foreach ($unsure as $key => $value) {
    		unlink($value);
    	}
    }
    


    $xfiles = glob($nolyricsdir."\*.txt");
    $yfiles = glob($unsurelyricsdir."\*.txt");

      if(count($yfiles) > 0){
    	echo '<tr><td colspan="5" style="text-align: center;border-bottom:solid 1px">LYRICS TO BE CHECKED</td></tr>';

    	foreach ($yfiles as $k => $val) {
    		$yfilename=basename($val);
	    	$ysongid=explode("_", $yfilename)[0];
	    	$ylyricscontent=false;
	    	$ytitlepart=-1;
	    	$ytitlecount=0;
	    	$ysong="";
			$ydata = file($val);
			$ynolyric=false;
			$ylink="";

		foreach (new SplFileObject($val) as $ylineNumber => $ylineContent) {
			
		    if($ylyricscontent==false) {
		    	if(stripos($ylineContent,"http://")!==false || stripos($ylineContent,"https://")!==false){
		    		$ylink=$ylineContent;
		    	}
		    	if(stripos($ylineContent,"Written by")!==false){
		        	$ylyricscontent=true;
		       		$ytitlepart= $ylineNumber-1;
		       	}
		    }
		    if(stripos($ylineContent,"Written by")==false && $ylyricscontent==true){

		    	$ysong=$ydata[count($ytitlepart)+1];

		    	$ytitle=explode("–", $ysong)[0];
		    	
		    }
		   
		}

			$yfile = new SplFileObject($val);
			$ylines="";
			$yfileIterator = new LimitIterator($yfile, 4, 5);

			foreach($yfileIterator as $yline) {
			    $ylines= $ylines.''.$yline.'<br/>';
			}

    		echo '<tr>
						<td  style="border-bottom:solid 1px">'.$ysongid.'</td>
						<td style="text-align: center;border-bottom:solid 1px">'.$ysong.'</td>
						<td  style="text-align: center;border-bottom:solid 1px"><a href="'.$ylink.'" target="_BLANK">'.$ylink.'</a></td>
						<td  style="text-align: center;border-bottom:solid 1px"><div class="hiddenlyrics" style="display:none">'.implode("<br/>", $ydata).'</div>'.$ylines.'</td>';
			echo "<td style='border-bottom:solid 1px'><input type='hidden' class='path' name='path' value='".$val."'/><button class='viewLyrics'>View full lyrics</button><button class='markCorrect'>Mark as correct</button></td>
						</tr>";
    	}
						
    }
     
    if(count($xfiles) > 0){
    	echo '<tr><td colspan="5" style="text-align: center;border-bottom:solid 1px">NO LYRICS</td></tr>';

    	foreach ($xfiles as $key => $value) {
    		$xfilename=basename($value);
	    	$xsongid=explode("_", $xfilename)[0];
	    	$xlyricscontent=false;
	    	$xtitlepart=-1;
	    	$xtitlecount=0;
	    	$xsong="";
			$xdata = file($value);
			$xnolyric=false;
			$xlink="";

		foreach (new SplFileObject($value) as $xlineNumber => $xlineContent) {
			
		    if($xlyricscontent==false) {
		    	if(stripos($xlineContent,"http://")!==false || stripos($xlineContent,"https://")!==false){
		    		$xlink=$xlineContent;
		    	}
		    	if(stripos($xlineContent,"Written by")!==false){
		        	$xlyricscontent=true;
		       		$xtitlepart= $xlineNumber-1;
		       	}
		    }
		    if(stripos($xlineContent,"Written by")==false && $xlyricscontent==true){

		    	$xsong=$xdata[count($xtitlepart)+1];

		    	$xtitle=explode("–", $xsong)[0];
		    	
		    }
		   
		}
		$sfile = new SplFileObject($value);
			$slines="";
			$sfileIterator = new LimitIterator($sfile, 4, 5);

			foreach($sfileIterator as $sline) {
				if($sline !='')
			    $slines= $slines.''.$sline.'<br/>';
			}

    		echo '<tr><td  style="border-bottom:solid 1px">'.$xsongid.'</td>
						<td style="text-align: center;border-bottom:solid 1px">'.$xsong.'</td>
						<td  style="text-align: center;border-bottom:solid 1px"><a href="'.$xlink.'" target="_BLANK">'.$xlink.'</a></td>
						<td  style="text-align: center;border-bottom:solid 1px">';
						if(iterator_count($sfileIterator) > 0){
							echo '<div class="hiddenlyrics" style="display:none">'.join("<br/>",$xdata).'</div>';
							echo $slines;
						}
						else{
							echo 'No Lyrics';
						}

						echo '</td>
						<td style="border-bottom:solid 1px"><input type="hidden" class="path" name="path" value="'.$value.'"/>';
						if(iterator_count($sfileIterator) == 0)
						echo '<button class="addlyric">Add lyrics</button>';
						else
						echo '<button class="viewLyrics">View Full lyrics</button>';
						echo '<button class="markCorrect2">Mark as correct</button></td>
						</tr>';
    	}
						
    }
    echo '</tbody>
	</table>';
   }

?>