<?php
//error_reporting(E_ERROR | E_PARSE);
if(isset($_GET['path'])){
	$path=$_GET['path'];
	 chmod($path,0777);
   $files = glob($path."\*.txt");
   if (!file_exists($path."\/nolyrics"))
   	mkdir($path."\/nolyrics");
 /*  if (!file_exists($path."\/unsurelyrics"))
   	mkdir($path."\/unsurelyrics");
   if (!file_exists($path."\/withlyricsdir"))
   	mkdir($path."\/withlyricsdir");*/



   $nolyricsdir=$path."\/nolyrics\/";
  /* $unsurelyricsdir=$path."\/unsurelyrics\/";
   $withlyricsdir=$path."\/withlyricsdir\/";*/

   chmod($nolyricsdir,0777);
   /*chmod($unsurelyricsdir,0777);
   chmod($withlyricsdir,0777);*/

   $delete=array();
    $nolyrics=array();
    $unsure=array();
    foreach($files as $file) {
    	chmod($file,0777);
    	$filename=basename($file);
    	
    	$songid=explode("_", $filename)[0];
    	$lyricscontent=false;
    	$titlepart=-1;
    	$titlecount=0;
    	$song="";
		$data = file($file);
		$nolyric=false;
		$link="";

		$d=new SplFileObject($file);
		foreach ($d as $lineNumber => $lineContent) {
		    if($lyricscontent==false) {
		    	if(stripos($lineContent,"http://")!==false || stripos($lineContent,"https://")!==false){
		    		$link=$lineContent;
		    	}
		    	if(stripos($lineContent,"Written by")!==false){
		        	$lyricscontent=true;
		       		$titlepart= $lineNumber-1;
		       	}
		    }
		    if(stripos($lineContent,"Written by")==false && $lyricscontent==true){
		    	if(stripos($lineContent, "No lyrics available") > -1){
		    		$nolyric=true;
		    		break;
		    	}
		    	 if(strpos($link, 'testicanzoni.mtv.it/') !== false && stripos($lineContent,"Sfortunatamente non abbiamo ancora questo testo ma puoi aggiungerlo cliccando")!==false){
					$nolyric=true;
		    		break;
	    		}

		    	$song=$data[count($titlepart)+1];
		    	$title=explode("–", $song)[0];
		    	
		    	if(stripos($lineContent,trim($title))!=false)
		    		$titlecount++;
		    }
		   // $wholelines=$wholelines.''.preg_replace("/[^a-z']+/i", '', $lineContent);
		}
		
		$line = $data[count($data)-1];
		if(stripos($line,"Written by")!==false){
			
			 if (copy($file, $nolyricsdir.'\/'.$filename)) {
			  		array_push($unsure, $file);
	         }
		}else{

			
			$lines="";
			$fileIterator = new LimitIterator($d, 4, 5);

			foreach($fileIterator as $k=>$line) {
				
			    $lines= $lines.''.$line.'<br/>';
			}
			if(iterator_count($fileIterator) > 2){
			  	if($titlecount==0){
			  		if($nolyric==false){
			  			if(strpos($lines, "We detected that your IP is blocked")!==false){
			  				if (copy($file, $nolyricsdir.'\/'.$filename)) {
			  				  array_push($unsure, $file);
				        	}
			  			}
			  			if(strpos($link, 'musica.com/') !== false && stripos($lines,"Letra ")!==false){

					    	 if (copy($file, $nolyricsdir.'\/'.$filename)) {
						  		array_push($unsure, $file);
				         	 }
				    	}

					}else{
						if (copy($file, $nolyricsdir.'\/'.$filename)) {
			  				  array_push($unsure, $file);
				        }
					}
	  			}else{}
			}else{
				if (copy($file, $nolyricsdir.'\/'.$filename)) {
					if (file_exists($file)){
						array_push($unsure, $file);
					}
		            
		         }

			}
		

    	}
    	$d=null;
    	
    }
    if(count($unsure) > 0){
    	foreach ($unsure as $key => $value) {
    		unlink($value);
    	}
    }
}
    


    $xfiles = glob($nolyricsdir."\*.txt");
  //  $yfiles = glob($unsurelyricsdir."\*.txt");

     /* if(count($yfiles) > 0){
    	echo '<tr><td colspan="5" style="text-align: center;border-bottom:solid 1px">LYRICS TO BE CHECKED</td></tr>';

    	foreach ($yfiles as $k => $val) {
    		$yfilename=basename($val);
	    	$ysongid=explode("_", $yfilename)[0];
	    	$ylyricscontent=false;
	    	$ytitlepart=-1;
	    	$ytitlecount=0;
	    	$ysong="";
			$ydata = file($val);
			$ynolyric=false;
			$ylink="";

		foreach (new SplFileObject($val) as $ylineNumber => $ylineContent) {
			
		    if($ylyricscontent==false) {
		    	if(stripos($ylineContent,"http://")!==false || stripos($ylineContent,"https://")!==false){
		    		$ylink=$ylineContent;
		    	}
		    	if(stripos($ylineContent,"Written by")!==false){
		        	$ylyricscontent=true;
		       		$ytitlepart= $ylineNumber-1;
		       	}
		    }
		    if(stripos($ylineContent,"Written by")==false && $ylyricscontent==true){

		    	$ysong=$ydata[count($ytitlepart)+1];

		    	$ytitle=explode("–", $ysong)[0];
		    	
		    }
		   
		}

			$yfile = new SplFileObject($val);
			$ylines="";
			$yfileIterator = new LimitIterator($yfile, 4, 5);

			foreach($yfileIterator as $yline) {
			    $ylines= $ylines.''.$yline.'<br/>';
			}

    		echo '<tr>
						<td  style="border-bottom:solid 1px">'.$ysongid.'</td>
						<td style="text-align: center;border-bottom:solid 1px">'.$ysong.'</td>
						<td  style="text-align: center;border-bottom:solid 1px"><a href="'.$ylink.'" target="_BLANK">'.$ylink.'</a></td>
						<td  style="text-align: center;border-bottom:solid 1px"><div class="hiddenlyrics" style="display:none">'.implode("<br/>", $ydata).'</div>'.$ylines.'</td>';
			echo "<td style='border-bottom:solid 1px'><input type='hidden' class='path' name='path' value='".$val."'/><button class='viewLyrics'>View full lyrics</button><button class='markCorrect'>Mark as correct</button></td>
						</tr>";
    	}
						
    }*/
     
    if(count($xfiles) > 0){
    	$nolyricslist=[];

    	foreach ($xfiles as $key => $value) {
    		$xfilename=basename($value);
	    	$xsongid=explode("_", $xfilename)[0];
	    	$xlyricscontent=false;
	    	$xtitlepart=-1;
	    	$xtitlecount=0;
	    	$xsong="";
			$xdata = file($value);
			$xnolyric=false;
			$xlink="";

		foreach (new SplFileObject($value) as $xlineNumber => $xlineContent) {
			
		    if($xlyricscontent==false) {
		    	if(stripos($xlineContent,"http://")!==false || stripos($xlineContent,"https://")!==false){
		    		$xlink=$xlineContent;
		    	}
		    	if(stripos($xlineContent,"Written by")!==false){
		        	$xlyricscontent=true;
		       		$xtitlepart= $xlineNumber-1;
		       	}
		    }
		    if(stripos($xlineContent,"Written by")==false && $xlyricscontent==true){

		    	$xsong=$xdata[count($xtitlepart)+1];

		    	$xtitle=explode("–", $xsong)[0];
		    	
		    }
		   
		}
	/*	$sfile = new SplFileObject($value);
			$slines="";
			$sfileIterator = new LimitIterator($sfile, 4, 5);

			foreach($sfileIterator as $sline) {
				if($sline !='')
			    $slines= $slines.''.$sline.'<br/>';
			}*/
			$xlink=remove_utf8_bom($xlink);
			array_push($nolyricslist, array('title'=>$xsong,'songid'=>$xsongid,'link'=>$xlink,'filename'=>$xfilename,'lyrics'=>''));

    	/*	echo '<tr><td  style="border-bottom:solid 1px">'.$xsongid.'</td>
						<td style="text-align: center;border-bottom:solid 1px">'.$xsong.'</td>
						<td  style="text-align: center;border-bottom:solid 1px"><a href="'.$xlink.'" target="_BLANK">'.$xlink.'</a></td>
						<td  style="text-align: center;border-bottom:solid 1px">';
						if(iterator_count($sfileIterator) > 0){
							echo '<div class="hiddenlyrics" style="display:none">'.join("<br/>",$xdata).'</div>';
							echo $slines;
						}
						else{
							echo 'No Lyrics';
						}

						echo '</td>
						<td style="border-bottom:solid 1px"><input type="hidden" class="path" name="path" value="'.$value.'"/>';
						if(iterator_count($sfileIterator) == 0)
						echo '<button class="addlyric">Add lyrics</button>';
						else
						echo '<button class="viewLyrics">View Full lyrics</button>';
						echo '<button class="markCorrect2">Mark as correct</button></td>
						</tr>';*/
    	}
    	echo json_encode($nolyricslist);
						
    }

function remove_utf8_bom($text)
{
    $bom = pack('H*','EFBBBF');
    $text = preg_replace("/^$bom/", '', $text);
    return $text;
}
 
?>