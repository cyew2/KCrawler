<?php
include 'clean.php';
$lyrics='';
if(isset($_POST['lyrics']) && $_POST['lyrics'] != "no lyrics"){
	$lyrics=nl2br($_POST['lyrics']);
	$lyrics=str_replace("<br />", "", $lyrics);
	$lyrics=strip_tags($lyrics,"<br>");
	
	$lyrics=str_replace("<br>", PHP_EOL,$lyrics);
	//$lyrics = converter($lyrics);
}else{
	$lyrics='';
}
saveTxtfile2($lyrics);

	echo json_encode(array('success'=>true,'lyrics'=>$lyrics));

?>