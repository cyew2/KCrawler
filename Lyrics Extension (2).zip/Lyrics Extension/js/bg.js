    chrome.extension.onRequest.addListener(function(request, sender, sendResponse) {
    	request.urlname=request.urlname.replace(/\s+/g, "");
        if(request.urlname==window.location.href){
            sendResponse({data: document.all[0].outerHTML});
        }else{
            sendResponse({});
        }
    });

            

            