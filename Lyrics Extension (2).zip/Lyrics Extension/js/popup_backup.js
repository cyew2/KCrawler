
function checkHTML(nolyrics,ctr,done,chrometab){

  var newURL=nolyrics[chrometab]['nolyrics'][ctr].link;

  if(done.indexOf(nolyrics[chrometab]['nolyrics'][ctr].filename)==-1){
    done.push(nolyrics[chrometab]['nolyrics'][ctr].filename);

    if(done.length==nolyrics[chrometab]['nolyrics'].length){
      $('#loadData').prop('disabled', false);
      //checkremaining();
    }


    var lyrics='';
    var xxx;
    var yyyy;

    if(newURL.indexOf('pdf_output.php')==-1){
      

        chrome.tabs.update(chrometab, {url: newURL});
          chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab){
            
            if(changeInfo.status=="loading"){
              if(!xxx){
             xxx=setTimeout(function(){
                window.stop();   
             },3000);
                }
           }
            
            if (changeInfo.status=='complete' && lyrics == '' ) {
               if(xxx){
                clearTimeout(xxx);
               }
               
            chrome.tabs.sendMessage(chrometab, {urlname:""+newURL+""},{frameId: 0}, function (response) {
              lyrics='';
              uri='';
            
              
              if(typeof(response) !=='undefined' ){
                if(uri==''){
                  alltext = response.data;
                  adding(newURL,alltext,nolyrics,ctr,done,chrometab);
                }
              }else{
                 setTimeout(function(){  
                ctr++;
                if(ctr < nolyrics[chrometab]['nolyrics'].length)
                  checkHTML(nolyrics,ctr,done,chrometab);
                 },500);
              }

            
            });
           
          }
          });
    }else{
      setTimeout(function(){  
      ctr++;

      if(ctr < nolyrics[chrometab]['nolyrics'].length)
        checkHTML(nolyrics,ctr,done,chrometab);
      },500);
    }
  }
}

function adding(newURL,alltext,nolyrics,ctr,done,chrometab){
   
   
      setTimeout(function(){
               nolyrics[chrometab]['nolyrics'][ctr]['lyrics']=checkWebsites(newURL,alltext);
                  
                 
                  var pth = $('#pathInput').val();
                  if(pth.substr(pth.length - 1)!='\\')
                  pth = pth +'\\';
                  if(nolyrics[chrometab]['nolyrics'][ctr]['lyrics'] !='no lyrics'){
                    var htt="<p> <img style='width:20px;' src='check.png'/>&nbsp;&nbsp;"+nolyrics[chrometab]['nolyrics'][ctr].link+"</p>";
                    $('#loadingLyrics').append(htt);
                    $('#lyricsCount').text($('#loadingLyrics').find('p').length);
                     setTimeout(function(){   
                            ctr++;
                            if(ctr < nolyrics[chrometab]['nolyrics'].length){
                              checkHTML(nolyrics,ctr,done,chrometab);
                            }
                           },1000);
                  }
                  
/*                  $.ajax({
                        url:"http://localhost/cleansing/addinglyrics.php",
                        type:'post',
                        dataType: 'json',
                        data:{'lyrics':nolyrics[chrometab]['nolyrics'][ctr]['lyrics'],'path':pth+'nolyrics\\'+nolyrics[chrometab]['nolyrics'][ctr].filename,'basepath':pth,'filename':nolyrics[chrometab]['nolyrics'][ctr].filename},
                        success:function( data ) {
                          
                         setTimeout(function(){   
                            ctr++;
                            if(ctr < nolyrics[chrometab]['nolyrics'].length){
                              checkHTML(nolyrics,ctr,done,chrometab);
                            }
                           },1000);
                        }
                  });*/
                  },500); 
                  
                }

function checkWebsites(newURL,alltext){
              var lyrics='';
               if(newURL.indexOf("genius.com/") > -1){
                  lyrics = $(alltext).find('.lyrics').find('section p:first').html();
                  if(typeof(lyrics) !=='undefined'){
                  var x = lyrics.lastIndexOf('<br>');
                  lyrics= lyrics.substring(0, x);
                  }else{
                    lyrics='';
                  }
                  
                  
                }else if(newURL.indexOf("musica.com/") > -1){
                  lyrics = $(alltext).find('p:first').html();
                }else if(newURL.indexOf("paroles-musique.com/") > -1){
                  if($(alltext).find('#lyrics').length > 0)
                    lyrics = $(alltext).find('#lyrics').html();
                }else if(newURL.indexOf("kkbox.com/") > -1){
                  if($(alltext).find('.lyrics').length > 0){
                    lyrics = $(alltext).find('.lyrics').html();
                    if($(alltext).find('.lyrics').find('br').length > 1)
                      lyrics = lyrics.substring(lyrics.indexOf('<br>'),lyrics.length);
                    else
                      lyrics="no lyrics";
                  }
                }else if(newURL.indexOf("lyrics.wikia.com/") > -1){
                  if($(alltext).find('.lyricbox').length > 0)
                    lyrics = $(alltext).find('.lyricbox').html();
                }else if(newURL.indexOf("albumcancionyletra.com/") > -1){
                  if($(alltext).find('.oldSong').length > 0){
                    lyrics = $(alltext).find('.oldSong').find('.nicEdit-main').html();
                  }else{
                    if($(alltext).find('.newSong').length > 0){
                      lyrics = $(alltext).find('.newSong').find('.nicEdit-main').html();
                    }
                    if($(alltext).find('.letra').length > 0){
                      lyrics = $(alltext).find('.letra').html();
                    }
                  }
                }else if(newURL.indexOf("lyricsreg.com/") > -1){
                  lyrics = $(alltext).find('#maincontent').html();
                  if(typeof(lyrics) !=='undefined'){
                  var x = lyrics.indexOf('<br>');
                  lyrics=lyrics.substring(x,lyrics.length);
                  lyrics= lyrics.substring(0,lyrics.indexOf('<div'));
                  }else{
                    lyrics='';
                  }
                
                }else if(newURL.indexOf("flashlyrics.com/") > -1){
                  if( $(alltext).find('.main-panel').find('.main-panel-content > span').length > 0)
                  lyrics = $(alltext).find('.main-panel-content').html();

                }else if(newURL.indexOf("stlyrics.com/") > -1){
                   $(alltext).find('.highlight').each(function(x,y){
                      lyrics = lyrics +$(y).html()+'<br>';
                    });

                }else if(newURL.indexOf("lyricsmode.com/") > -1){
                  if( $(alltext).find('#lyrics_text').length > 0)
                  lyrics = $(alltext).find('#lyrics_text').html();

                }else if(newURL.indexOf("lyricsfreak.com/") > -1){
                  if( $(alltext).find('#content').length > 0)
                    lyrics = $(alltext).find('#content').html();

                }else if(newURL.indexOf("testicanzoni.mtv.it/") > -1){
                  if( $(alltext).find('.testo').find('blockquote').length > 0)
                  lyrics = $(alltext).find('.testo').find('blockquote').html();
                }else if(newURL.indexOf("vagalume.com") > -1){
                  if( $(alltext).find('#lyr_original').find('div').length > 0)
                  lyrics = $(alltext).find('#lyr_original').find('div').html();
                }else if(newURL.indexOf("coveralia.com/") > -1){
                  if( $(alltext).find('#HOTWordsTxt').length > 0)
                  lyrics = $(alltext).find('#HOTWordsTxt').html();
                }else if(newURL.indexOf("lyrics.com/") > -1){
                  if( $(alltext).find('.lyric-body').length > 0)
                  lyrics = $(alltext).find('.lyric-body').html();
                }else if(newURL.indexOf("justsomelyrics.com/") > -1){
                  if( $(alltext).find('.content').find('p').length > 0)
                  lyrics = $(alltext).find('.content').find('p').html();
                }else if(newURL.indexOf("lyrics.jetmute.com/") > -1){
                  if( $(alltext).find('#lyricsText').length > 0)
                  lyrics = $(alltext).find('#lyricsText').html();
                }else if(newURL.indexOf("letras.com/") > -1){
                  if( $(alltext).find('article').find('p').length > 0){
                    $(alltext).find('article').find('p').each(function(x,y){
                      lyrics = lyrics +$(y).html();
                    });
                  }
                  
                }else if(newURL.indexOf("musixmatch.com/") > -1){
                  if(newURL.indexOf("/translation/") > -1){
                     $(alltext).find('.mxm-lyrics').find('.mxm-translatable-line-readonly').each(function(x,y){
                      lyrics = lyrics +$(y).find('.col-xs-6:first').text()+'<br>';
                    });
                     
                  }else{
                  $(alltext).find('.mxm-lyrics').find('.mxm-lyrics__content').each(function(x,y){
                    lyrics = lyrics +$(y).html();
                  });
                  }
                }else if(newURL.indexOf("metrolyrics.com/") > -1){

                if(typeof($(alltext).find('.lyric-message'))==='undefined'){
                  $(alltext).find('#lyrics-body-text').find('.verse').each(function(x,y){
                    lyrics = lyrics +$(y).html();
                  });
                }
                  
                }else if(newURL.indexOf("karaoketexty.cz/") > -1){
                  lyrics = $(alltext).find('#left_column').find('.text').html();

                }else if(newURL.indexOf("manutsi.wordpress.com/") > -1){
                  if($(alltext).find('.entry-content').find('h6').length > 0)
                  lyrics="<br>";
                  $(alltext).find('.entry-content').find('h6').each(function(x,y){
                    lyrics = lyrics +$(y).text()+'<br>';
                  });
                  
                }else if(newURL.indexOf("lyriczz.com/") > -1){
                    lyrics = $(alltext).find('.lyriczz').html();

                }else if(newURL.indexOf("diliriklagu.com/") > -1){
                  $(alltext).find('#lyrics-body-text').find('.verse').each(function(x,y){
                    lyrics = lyrics +$(y).html();
                  });
                }else if(newURL.indexOf('lyricsin.com/') > -1){
                  $(alltext).find('.post-content').find('p').each(function(x,y){
                    lyrics = lyrics +$(y).html();
                  });
                  
                }else if(newURL.indexOf('rockol.it/') > -1){
                  lyrics = $(alltext).find('.lyrics_body').find('.mod-lyrics').html();
                }else if(newURL.indexOf('xiami.com/') > -1){
                  lyrics = $(alltext).find('#info_intro').find('li:first').html();
                }else if(newURL.indexOf('liriklaguindonesia.net/') > -1){
                  $(alltext).find('.clear').find('h2').nextAll('p').each(function(x,y){
                    lyrics = lyrics +$(y).html();
                  });
                }else if(newURL.indexOf('smule.com/') > -1){
                  lyrics= $(alltext).find('.lyrics').find('p').html();
                }else if(newURL.indexOf("elyrics.net/") > -1){
                  lyrics=$(alltext).find('.ly').find('#inlyr').html();
                }else if(newURL.indexOf("songtexte.com/") > -1){
                  lyrics=$(alltext).find('#lyrics').html();
                  if(typeof(lyrics) !=='undefined')
                  if(lyrics.indexOf('Leider kein Songtext vorhanden') > -1)
                    lyrics='';
                }else{
                  lyrics="no lyrics";
                }
                if(lyrics=='')
                  lyrics="no lyrics";
                 if(typeof(lyrics) ==='undefined')
                  lyrics="no lyrics";
                  
                return lyrics;

}


function checkRemaining(){
  var val=$('#pathInput').val();
              if(val!=''){
              $.ajax( {
                    url:"http://localhost/cleansing/checkremaining.php?path="+val,
                    type:'get',
                    dataType: 'json',
                    success:function( data ) {
                      $('#nolyricsCountTotal').html(data.count);
                  }
              });
            }
}


        $(document).ready(function () {
            $('#loadData').on('click',function(){
              var val=$('#pathInput').val();
              if(val!=''){
                $(this).prop('disabled', true);
                      var chrometabs=[];
                      var lyriclist=[];
                      chrome.tabs.query({active:true},function(tab){
                        chrometabs[0]={"tabID":tab[0].id,"processing":false};
                        lyriclist[tab[0].id]=[];
                        chrome.tabs.create({active:false},function(t){
                             chrometabs[1]={"tabID":t.id,"processing":false};
                            lyriclist[t.id]=[];
                        });
                       

                         $.ajax({
                              url:"http://localhost/cleansing/main.php?path="+val,
                              type:'get',
                              dataType: 'json',
                              success:function( data ) {
                                var nolyrics=data;

                                var ctr=0;
                                var done=[];
                                var count=nolyrics.length/chrometabs.length;
                                $('#nolyricsCountInitial').html(nolyrics.length);

                                  for (var i = 0; i < chrometabs.length; i++) {
                                      var ctr=0;
                                      var done=[];
                                      if(i < chrometabs.length-1)
                                      var nolyricstoprocess = nolyrics.splice(0,count);
                                      if(i == chrometabs.length-1)
                                      var nolyricstoprocess = nolyrics.splice(0,nolyrics.length);
                                      console.log(nolyricstoprocess);
                                      lyriclist[chrometabs[i].tabID].nolyrics=nolyricstoprocess;
                                      checkHTML(lyriclist,ctr,done,chrometabs[i].tabID);
                                  }
                                
                                
                            }
                        });
                        
                       
                      });
                      
                      

/*              $.ajax( {
                    url:"http://localhost/cleansing/main.php?path="+val,
                    type:'get',
                    dataType: 'json',
                    success:function( data ) {
                      var nolyrics=data;
                      var ctr=0;
                      var done=[];
                      $('#nolyricsCountInitial').html(nolyrics.length);
                      var chrometabs=[];
                      var activeTab = chrome.tabs.query({active:true});
                      chrometabs[0]=["tabID":activeTab[0].id,"processing":false];
                      for (var i = 1; i > 3; i++) {
                        var ee=chrome.tabs.create();
                        chrometabs[0]=["tabID":ee.id,"processing":false];
                      }
                      checkHTML(nolyrics,ctr,done,chrometabs);
                           

                      //  });
                     // });
                  }
              });*/
            }
             // var newURL = "https://genius.com/The-damned-citadel-lyrics";
    //chrome.tabs.create({ url: newURL,active:true,selected:true },function(tab){
     /* chrome.tabs.query({active:true},function(tab){
        chrome.tabs.sendMessage(tab[0].id, {method: "getText"}, function (response) {
          alltext = response.data;
          if(newURL.indexOf("https://genius.com/") > -1){
            console.log($(alltext).find('.lyrics').find('p:first').html());
          }
        });*/
      //});
   // });
            });
            

        
        });