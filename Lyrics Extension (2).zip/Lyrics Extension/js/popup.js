
    // Enable pusher logging - don't include this in production
    Pusher.logToConsole = true;

   var pusher = new Pusher('221fa851388dc7a951a4', {
      cluster: 'ap1',
      encrypted: true
    });

    var channel = pusher.subscribe('my-channel');
    var xx=0;
    channel.bind('my-event', function(data) {
      var list = $('#nolyricsList').val();
      if($('#processing').val()=="false"){
        $('#processing').val('true');
        
        if(list != ''){
          list=JSON.parse(list);
          addToArray(data);         
          checkHTML();
              
        }else{
          $('#processing').val('false');
          addToArray(data);
          checkHTML();
        }
      }else{
        addToArray(data);
      }
    });



    channel.bind('my-count', function(data) {
      $('#successSearch').html(data.success);
      $('#failedSearch').html(data.fail);
      $('#currentSearch').html(data.processed);
      $('#lyricsCount').html(data.lyricsCount);
      $('#singerMatchLyrics').html(data.singerMatchLyrics);
      $('#singerNoMatchLyrics').html(data.singerNoMatchLyrics);
      $('#singerMatchNoLyrics').html(data.singerMatchNoLyrics);
      $('#singerNoMatchNoLyrics').html(data.singerNoMatchNoLyrics);
      if(data.lyricsCount==data.processed){
         $('#loadData').prop('disabled', false);
         $('.crawlingResults1').hide();
         saveHtmlAndClose();
      }
    });

    function saveHtmlAndClose(){
      var intervalHandle=null;
      intervalHandle = setInterval(function(){
        var list=[];
        var done=[];
        if($('#nolyricsList').val() !='')
         list= JSON.parse($('#nolyricsList').val());
        if($('#doneList').val() !='')
          done= $('#doneList').val().split(',');
        if(done.length==list.length){
         
            clearInterval(intervalHandle);
            setTimeout(function(){
              rank();
            },1000);
            
        }else{
              checkHTML();
        }
      },10000);      
    }

    function rank(){
      var f = $('#processingExcel').val();
      var listx = $('#jsonList').val();
      if(listx !=''){
        listx=JSON.parse(listx);
      
        $.ajax({
            url:"http://localhost/crawlerRefactor/rank.php?filename="+f,
            type:'post',
            data:{list:listx},
            dataType: 'json',
            success:function( data ){
              var windowid = $('#windowID').val();
              chrome.windows.get(parseInt(windowid),{populate:true},function(win){
                console.log(win.tabs[0].id);
                chrome.tabs.executeScript(win.tabs[0].id, { "code": "document.documentElement.outerHTML;"}, function (result) {
                  var val=$('#pathInput').val();
                  $.ajax({
                    url:"http://localhost/crawlerRefactor/saveHtml.php",
                    type:'post',
                    data:{'html':result,'basepath':val,'filex':f},
                    dataType: 'json',
                    success:function( data ) {
                      setTimeout(function(){
                        chrome.windows.remove(parseInt(windowid), function(){
                          $('#nolyricsList').val('');
                          $('#jsonList').val('');
                          $('#nolyricsCtr').val(0);
                          $('#doneList').val('');
                          $('#processingExcel').val('');
                          $('#windowID').val('');
                          $('#processing').val('false');
                          $('#loadingLyrics').html('');
                          $('#singerMatchLyrics').html('0');
                          $('#singerNoMatchLyrics').html('0');
                          $('#singerMatchNoLyrics').html('0');
                          $('#singerNoMatchNoLyrics').html('0');
                          $('#lyricsCount').html('0');
                          $('#successSearch').html('0');
                          $('#failedSearch').html('0');
                          $('#currentSearch').html('0');
                          $('.crawlingResults1').hide();
                          newExcel();
                        });
                      },1000);
                    }
                  });
                  
                });
              });
            }
        });
      }else{
        var windowid = $('#windowID').val();
        chrome.windows.get(parseInt(windowid),{populate:true},function(win){
          chrome.tabs.executeScript(win.tabs[0].id, { "code": "document.documentElement.outerHTML;"}, function (result) {
            var val=$('#pathInput').val();
            $.ajax({
              url:"http://localhost/crawlerRefactor/saveHtml.php",
              type:'post',
              data:{'html':result,'basepath':val,'filex':f},
              dataType: 'json',
              success:function( data ) {
                setTimeout(function(){
                  chrome.windows.remove(parseInt(windowid), function(){
                    $('#nolyricsList').val('');
                    $('#jsonList').val('');
                    $('#nolyricsCtr').val(0);
                    $('#doneList').val('');
                    $('#processingExcel').val('');
                    $('#windowID').val('');
                    $('#processing').val('false');
                    $('#loadingLyrics').html('');
                    $('#singerMatchLyrics').html('0');
                    $('#singerNoMatchLyrics').html('0');
                    $('#singerMatchNoLyrics').html('0');
                    $('#singerNoMatchNoLyrics').html('0');
                    $('#lyricsCount').html('0');
                    $('#successSearch').html('0');
                    $('#failedSearch').html('0');
                    $('#currentSearch').html('0');
                    $('.crawlingResults1').hide();
                    newExcel();
                  });
                },1000);
              }
            });
            
          });
        });
      }
    }

    function newExcel(){
      var filenames=JSON.parse($('#excelList').val());
      var tobeProcessed=filenames.shift();
      $('#processingExcel').val(tobeProcessed);
      chrome.windows.create({url:"http://localhost/crawlerRefactor/main.php?path="+tobeProcessed,focused:false},function(window) {
         $('.crawlingResults1').show();
         $('.crawlingResults1').html('Crawler is running...');
         $('.crawlingResults').show();
         console.log(filenames+'FFFFFFF');
        $('#excelList').val(JSON.stringify(filenames));
        $('#windowID').val(window.id);
      });
    }

function removeFromList(){
    var list2 = $('#nolyricsList').val();
    list2=JSON.parse(list2);
    list2.splice(0,1);
    $('#nolyricsList').val(JSON.stringify(list2));
};

function addToArray(arr){
  var list2 = $('#nolyricsList').val();
  if(list2 !=''){
    list2=JSON.parse(list2);
    list2.push(arr);
  }else{
    list2=[];
    list2.push(arr);
  }
  $('#nolyricsList').val(JSON.stringify(list2));
}

function checkHTML(){
  
  var list2 = $('#nolyricsList').val();
  var donelist=[];
  if($('#doneList').val() != ''){
    donelist = $('#doneList').val();
    donelist=donelist.split(',');
  }
  var ctr = parseInt($('#nolyricsCtr').val());
  list2=JSON.parse(list2);
  if(typeof(list2[ctr]) !=='undefined'){
    if(donelist.indexOf(list2[ctr].filename) == -1){
    var newURL=list2[ctr].link;
    donelist.push(list2[ctr].filename);
    $('#doneList').val(donelist.join());
    console.log(donelist.length+'/'+list2.length);
    $('#processing').val('true');

      var lyrics='';
      var xxx=null;
      var yyyy='';
      var wwww=null;

      if(newURL.indexOf('pdf_output.php')==-1){
            chrome.tabs.query({active:true},function(tab){
              chrome.tabs.update(tab[0].id, {url: newURL});
              chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab){

                    clearTimeout(xxx);
                    clearInterval(wwww);

                  if (changeInfo.status=='complete') {
                   
                    chrome.tabs.sendRequest(tab.id, {urlname:""+newURL+""}, function (response) {
                                          
                      if(yyyy==''){
                        yyyy='set';
                      if(typeof(response) !=='undefined'){
                       
                        
                          
                          alltext = response.data;
                          adding(newURL,alltext,list2[ctr].filename);   
                        
                      }else{
                          console.log('CALLED HERE...'+newURL);
                          adding(newURL,null,list2[ctr].filename);
                          console.log($('#pastCtrl').val()+'/'+$('#nolyricsCtr').val());
                          wwww = setInterval(function(){
                             console.log('CONSOLE...');
                            if(((parseInt($('#pastCtrl').val()) + 1) == parseInt($('#nolyricsCtr').val())) && typeof(list2[parseInt($('#nolyricsCtr').val())]) !=='undefined'){
                              chrome.tabs.reload(tab.id,function(){ console.log('RELOADED'); });
                            }
                          },10000);
                        
                      }
                    }
                    })
                  }else{
                    if(newURL.indexOf('azlyrics.com') == -1){
                      if(xxx==null)
                        xxx = setTimeout(function(){

                          chrome.tabs.executeScript(tab.id,{
                            code:"window.stop();",
                            runAt: "document_start"
                          });
                        },5000);
                    }
                  }
              }); 
            });
      }else{
          $('#nolyricsCtr').val(ctr + 1);
          $('#pastCtrl').val(ctr);
          checkHTML();
      }
    }else{
      $('#nolyricsCtr').val(ctr + 1);
      $('#pastCtrl').val(ctr);
      checkHTML();
    }
  }else{
    $('#processing').val('false');
  }
}

  function adding(newURL,alltext,filename){
    var list2 = $('#nolyricsList').val();
    var ctr = parseInt($('#nolyricsCtr').val());
    list2=JSON.parse(list2);
    var lyrics='';
   
    

    setTimeout(function(){
       if(alltext==null){
        lyrics='no lyrics';
      }else{
        lyrics=checkWebsites(newURL,alltext);
      }
      
      if(lyrics !='no lyrics'){
          var htt="<p> <img style='width:20px;' src='check.png'/>&nbsp;&nbsp;"+list2[ctr].link+"</p>";
          $('#loadingLyrics').append(htt);
          $('#lyricsCount').text($('#loadingLyrics').find('p').length);
      }
      
       list2[ctr]['jsondata']['lyrics']=lyrics;
       $.ajax({
              url:"http://localhost/cleansing/addinglyrics.php",
              type:'post',
              dataType: 'json',
             data:{'data':list2[ctr]['jsondata'],'filename':filename,'dirname':list2[ctr]['dirname'],'firstline':list2[ctr]['firstline']},
              success:function( data ) { 
               
                list2[ctr]['jsondata']['lyrics']=data.lyrics;
                var ccc = $('#jsonList').val();
                if(ccc !=''){
                  ccc=JSON.parse(ccc);
                  ccc.push(list2[ctr]['jsondata']);
                }else{
                  ccc=[];
                  ccc.push(list2[ctr]['jsondata']);
                }
                $('#jsonList').val(JSON.stringify(ccc));
                 $('#nolyricsCtr').val(ctr + 1);
                 $('#pastCtrl').val(ctr);
                 checkHTML();
               
              }
        });
      },1000); 
  }

   function adding2(newURL,alltext){
    setTimeout(function(){
      var lyrics=checkWebsites(newURL,alltext);
      $.ajax({
        url:"http://localhost/cleansing/addinglyrics2.php",
        type:'post',
        dataType: 'json',
       data:{'lyrics':lyrics},
        success:function( data ) { 
         
         
        }
        });
    },2000);

   }

   function testWeb(){
    var newURL="https://www.letras.mus.br/orquestra-da-terra/1643880/";
       var lyrics='';
      var xxx=null;
      var yyyy='';
      var wwww=null;

      if(newURL.indexOf('pdf_output.php')==-1){
            chrome.tabs.query({active:true},function(tab){
              chrome.tabs.update(tab[0].id, {url: newURL});
              chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab){
                  if (changeInfo.status=='complete') {
                    clearTimeout(xxx);
                    chrome.tabs.sendRequest(tab.id, {urlname:""+newURL+""}, function (response) {
                    //chrome.tabs.executeScript(tabId, { "code": "document.all[0].outerHTML;","allFrames":true,"frameId":0 }, function (response) {
                      console.log(response);
                      if(yyyy==''){
                        yyyy='set';
                      if(typeof(response) !=='undefined'){
                        console.log('CALLED...');
                        
                          
                          alltext = response.data;
                          adding2(newURL,alltext);   
                        
                      }else{
                          console.log('CALLED HERE...');
                          adding2(newURL,null);
                          setTimeout(function(){
                             console.log('CONSOLE...');
                            if(parseInt($('#pastCtrl').val() + 1) == parseInt($('#nolyricsCtr').val())){
                              $('#nolyricsCtr').val(parseInt($('#nolyricsCtr').val()) + 1);
                              $('#processing').val('false');
                              checkHTML();
                              console.log('XXXXXX'+$('#pastCtrl').val());
                            }
                          },5000);
                        
                      }
                    }
                    })
                  }else{
                  if(xxx==null)
                    xxx = setTimeout(function(){
                      chrome.tabs.executeScript(tab.id,{
                        code:"window.stop();",
                        runAt: "document_start"
                      });
                    },5000);
                  };
              }); 
            });
      }else{
          $('#nolyricsCtr').val(ctr + 1);
          $('#pastCtrl').val(ctr);
          checkHTML();
      }
   }

function checkWebsites(newURL,alltext){
              var lyrics='';
              console.log(newURL);
               if(newURL.indexOf("genius.com/") > -1){
                  lyrics = $(alltext).find('.lyrics').find('section p:first').html();
                  if(lyrics=='' || typeof(lyrics)=='undefined')
                    lyrics= $(alltext).find('.lyrics').find('section > hr').next().html();
                  if(typeof(lyrics) !=='undefined'){
                  var x = lyrics.lastIndexOf('<br>');
                  lyrics= lyrics.substring(0, x);
                  }else{
                    lyrics='';
                  }
                };
                if(newURL.indexOf("musica.com/") > -1){
                  lyrics = $(alltext).find('p:first').html();
                };
                if(newURL.indexOf("paroles-musique.com/") > -1){
                  if($(alltext).find('#lyrics').length > 0)
                    lyrics = $(alltext).find('#lyrics').html();
                };
                if(newURL.indexOf("kkbox.com/") > -1){
                  if($(alltext).find('.lyrics').length > 0){
                    lyrics = $(alltext).find('.lyrics').html();
                    if($(alltext).find('.lyrics').find('br').length > 1)
                      lyrics = lyrics.substring(lyrics.indexOf('<br>'),lyrics.length);
                    else
                      lyrics="no lyrics";
                  }
                };
                if(newURL.indexOf("lyrics.wikia.com/") > -1){
                  if($(alltext).find('.lyricbox').length > 0)
                    lyrics = $(alltext).find('.lyricbox').html();
                  window.stop();
                }
                if(newURL.indexOf("metal-head.org/") > -1){
                  if($(alltext).find('#songlyrics').length > 0)
                    lyrics = $(alltext).find('#songlyrics').html();
                }
                if(newURL.indexOf("mojim.com/") > -1){
                  if($(alltext).find('.fsZx3').length > 0)
                    lyrics = $(alltext).find('.fsZx3').html();
                }
                if(newURL.indexOf("azlyrics.com/") > -1){
                  /*if($(alltext).find('.ringtone + div').length > 0)
                    lyrics = $(alltext).find('.text-center').html();*/
                    lyrics = $(alltext).find('.ringtone').next().next().next().next().html();
                  
                }
                if(newURL.indexOf("lookingforlyrics.mobi/") > -1){
                  if($(alltext).find('.play-list > textarea') > 0){
                   lyrics = $(alltext).find('.play-list > textarea').val();
                  }
                }
                if(newURL.indexOf("golyr.de/") > -1){
                  if($(alltext).find('#lyrics').length > 0)
                    lyrics = $(alltext).find('#lyrics').html();
                }
                if(newURL.indexOf("albumcancionyletra.com/") > -1){
                  if($(alltext).find('.oldSong').length > 0){
                    lyrics = $(alltext).find('.oldSong').find('.nicEdit-main').html();
                  }else{
                    if($(alltext).find('.newSong').length > 0){
                      lyrics = $(alltext).find('.newSong').find('.nicEdit-main').html();
                    }
                    if($(alltext).find('.letra').length > 0){
                      lyrics = $(alltext).find('.letra').html();
                    }
                  }
                }
                if(newURL.indexOf("lyricsreg.com/") > -1){
                  lyrics = $(alltext).find('#maincontent').html();
                  if(typeof(lyrics) !=='undefined'){
                  var x = lyrics.indexOf('<br>');
                  lyrics=lyrics.substring(x,lyrics.length);
                  lyrics= lyrics.substring(0,lyrics.indexOf('<div'));
                  }else{
                    lyrics='';
                  }
                
                }
                if(newURL.indexOf("lirik.kapanlagi.com/") > -1){
                  $(alltext).find('.lirik_line').each(function(x,y){
                      lyrics = lyrics +$(y).html()+'<br>';
                    });
                }
                if(newURL.indexOf("letras.mus.br/") > -1){
                  if( $(alltext).find('.cnt-letra > article').length > 0)
                    $(alltext).find('.cnt-letra > article').find('p').each(function(x,y){
                      lyrics = lyrics +$(y).html()+'<br>';
                    });
                }
                if(newURL.indexOf("flashlyrics.com/") > -1){
                  if( $(alltext).find('.main-panel').find('.main-panel-content > span').length > 0)
                  lyrics = $(alltext).find('.main-panel-content').html();

                }
                if(newURL.indexOf("stlyrics.com/") > -1){
                   $(alltext).find('.highlight').each(function(x,y){
                      lyrics = lyrics +$(y).html()+'<br>';
                    });

                }
                if(newURL.indexOf("lyricsmode.com/") > -1){
                  if( $(alltext).find('#lyrics_text').length > 0)
                  lyrics = $(alltext).find('#lyrics_text').html();

                }
                if(newURL.indexOf("lyricsfreak.com/") > -1){
                  if( $(alltext).find('#content').length > 0)
                    lyrics = $(alltext).find('#content').html();

                }
                if(newURL.indexOf("testicanzoni.mtv.it/") > -1){
                  if( $(alltext).find('.testo').find('blockquote').length > 0)
                  lyrics = $(alltext).find('.testo').find('blockquote').html();
                }
                if(newURL.indexOf("library.timelesstruths.org/") > -1){
                  if( $(alltext).find('.lyrics').find('.verses').length > 0)
                    $(alltext).find('.lyrics').find('li').each(function(x,y){
                      lyrics = lyrics +$(y).html()+'<br>';
                    });
                }
                if(newURL.indexOf("vagalume.com") > -1){
                  if( $(alltext).find('#lyr_original').find('div').length > 0)
                  lyrics = $(alltext).find('#lyr_original').find('div').html();
                }
                if(newURL.indexOf("coveralia.com/") > -1){
                  if( $(alltext).find('#HOTWordsTxt').length > 0)
                  lyrics = $(alltext).find('#HOTWordsTxt').html();
                }
                if(newURL.indexOf("lyrics.com/") > -1){
                  if( $(alltext).find('.lyric-body').length > 0)
                  lyrics = $(alltext).find('.lyric-body').html();
                }
                if(newURL.indexOf("letssingit.com/") > -1){
                  if( $(alltext).find('#lyrics').length > 0)
                  lyrics = $(alltext).find('#lyrics').html();
                }
                if(newURL.indexOf("azchords.com/") > -1){
                  if( $(alltext).find('#content').length > 0)
                  lyrics = $(alltext).find('#content').html();
                }
                if(newURL.indexOf("lyricstranslate.com/") > -1){
                  if( $(alltext).find('.ltf > .par').length > 0)
                  $(alltext).find('.ltf > .par').find('div').each(function(x,y){
                    lyrics = lyrics +$(y).html();
                  });
                }
                if(newURL.indexOf("allthelyrics.com/") > -1){
                  if( $(alltext).find('.content-text').length > 0)
                  $(alltext).find('.content-text').find('p').each(function(x,y){
                    lyrics = lyrics +$(y).html()+'<br>';
                  });
                  if(lyrics=='' || typeof(lyrics)==='undefined'){
                    $(alltext).find('.content > blockquote').length > 0
                    lyrics = $(alltext).find('.content > blockquote').html();
                  }
                }

                if(newURL.indexOf("justsomelyrics.com/") > -1){
                  if( $(alltext).find('p').length > 0)
                  $(alltext).find('p').each(function(x,y){
                      lyrics = lyrics +$(y).html()+'<br>';
                    });
                }
                if(newURL.indexOf("lyrics.jetmute.com/") > -1){
                  if( $(alltext).find('#lyricsText').length > 0)
                  lyrics = $(alltext).find('#lyricsText').html();
                }
                if(newURL.indexOf("planet-tango.com/") > -1){
                  if( $(alltext).find('.lyrics',0).length > 0)
                  lyrics = $(alltext).find('.lyrics',0).html();
                }
                if(newURL.indexOf("letrasmania.com/") > -1){
                  if( $(alltext).find('.lyrics-body').length > 0)
                  lyrics = $(alltext).find('.lyrics-body').html();
                }
                if(newURL.indexOf("letras.com/") > -1){
                  if( $(alltext).find('article').find('p').length > 0){
                    $(alltext).find('article').find('p').each(function(x,y){
                      lyrics = lyrics +$(y).html();
                    });
                  }
                  
                }
                if(newURL.indexOf("musixmatch.com/") > -1){
                  if(newURL.indexOf("/translation/") > -1 || newURL.indexOf("/traduccion/") > -1){
                     $(alltext).find('.mxm-lyrics').find('.mxm-translatable-line-readonly').each(function(x,y){
                      lyrics = lyrics +$(y).find('.col-xs-6:first').text()+'<br>';
                    });
                     console.log(lyrics);
                  }else{
                  $(alltext).find('.mxm-lyrics').find('.mxm-lyrics__content').each(function(x,y){
                    lyrics = lyrics +$(y).html();
                  });
                  }
                }
                if(newURL.indexOf("metrolyrics.com") > -1){
                  console.log('TEST')

                  $(alltext).find('#lyrics-body-text').find('.verse').each(function(x,y){
                    lyrics = lyrics +$(y).html();
                  });
                }
                if(newURL.indexOf("karaoketexty.cz/") > -1){
                  lyrics = $(alltext).find('.text').html();

                }
                if(newURL.indexOf("manutsi.wordpress.com/") > -1){
                  if($(alltext).find('.entry-content').find('h6').length > 0)
                  lyrics="<br>";
                  $(alltext).find('.entry-content').find('h6').each(function(x,y){
                    lyrics = lyrics +$(y).text()+'<br>';
                  });
                  
                }
                if(newURL.indexOf("lyriczz.com/") > -1){
                    lyrics = $(alltext).find('.lyriczz').html();

                }
                if(newURL.indexOf("diliriklagu.com/") > -1){
                  $(alltext).find('#lyrics-body-text').find('.verse').each(function(x,y){
                    lyrics = lyrics +$(y).html();
                  });
                }
                if(newURL.indexOf('lyricsin.com/') > -1){
                  $(alltext).find('.post-content').find('p').each(function(x,y){
                    lyrics = lyrics +$(y).html();
                  });
                  
                }
                if(newURL.indexOf('rockol.it/') > -1){
                  lyrics = $(alltext).find('.lyrics_body').find('.mod-lyrics').html();
                }
                if(newURL.indexOf('xiami.com/') > -1){
                  lyrics = $(alltext).find('#info_intro').find('li:first').html();
                  if(typeof(lyrics)==='undefined' || lyrics==''){
                    lyrics = $(alltext).find('#lrc_main').html();
                  }
                }
                if(newURL.indexOf('liriklaguindonesia.net/') > -1){
                  $(alltext).find('.clear').find('h2').nextAll('p').each(function(x,y){
                    lyrics = lyrics +$(y).html();
                  });
                }
                if(newURL.indexOf('smule.com/') > -1){
                  lyrics= $(alltext).find('.lyrics').find('p').html();
                }
                if(newURL.indexOf("elyrics.net/") > -1){
                  lyrics=$(alltext).find('.ly').find('#inlyr').html();
                }
                if(newURL.indexOf("songtexte.com/") > -1){
                  lyrics=$(alltext).find('#lyrics').html();
                  if(typeof(lyrics) !=='undefined')
                  if(lyrics.indexOf('Leider kein Songtext vorhanden') > -1)
                    lyrics='';
                }
                if(lyrics=='')
                  lyrics="no lyrics";
                if(typeof(lyrics) ==='undefined')
                  lyrics="no lyrics";
              
                  
                return lyrics;

}

    $(document).ready(function () {
      //testWeb();
      $('#loadData').on('click',function(){
        var val=$('#pathInput').val();
        if(val!=''){
         $.ajax({
            url:"http://localhost/crawlerRefactor/test.php?foldername="+val,
            type:'get',
            dataType: 'json',
            success:function( data ) {
              var filenames=data.names;
              if(filenames.length == 0){
                 $('.crawlingResults1').show();
                  $('.crawlingResults1').html('No excel files found.');
              }else{
                var tobeProcessed=filenames.shift();
                $('#processingExcel').val(tobeProcessed);
                chrome.windows.create({url:"http://localhost/crawlerRefactor/main.php?path="+tobeProcessed,focused:false},function(window) {
                   $('.crawlingResults1').show();
                   $('.crawlingResults1').html('Crawler is running...');
                   $('.crawlingResults').show();
                  $('#excelList').val(JSON.stringify(filenames));
                  $('#windowID').val(window.id);
                });
                

              }
            }
          });
          /*$(this).prop('disabled', true);
          $('.crawlingResults1').show();
          $('.crawlingResults').show();
          chrome.windows.create({url:"http://localhost/crawlerRefactor/main.php?path="+val,focused:false});
*/
       }
             });
    });